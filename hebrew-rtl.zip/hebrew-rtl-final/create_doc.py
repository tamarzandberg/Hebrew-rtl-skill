"""
Helper script: creates a Hebrew RTL docx from the bundled template.
Usage: python3 create_doc.py <output_path>
The template is in the same directory as this script.
"""
import zipfile, os, re, sys
import base64

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(SCRIPT_DIR, 'hebrew_template.docx')

def build_hebrew_docx(paragraphs_xml, output_path, template_path=None):
    """
    Build a Hebrew RTL docx from the bundled template.
    paragraphs_xml: list of XML paragraph strings
    output_path: where to save the output docx
    """
    tpl = template_path or TEMPLATE_PATH
    work_dir = '/tmp/heb_work'
    
    import shutil
    if os.path.exists(work_dir):
        shutil.rmtree(work_dir)
    os.makedirs(work_dir)
    
    with zipfile.ZipFile(tpl, 'r') as z:
        z.extractall(work_dir)
    
    orig = open(os.path.join(work_dir, 'word/document.xml'), encoding='utf-8').read()
    ns_part = orig[:orig.index('<w:body>')]
    sectPr = re.search(r'<w:sectPr.*?</w:sectPr>', orig, re.DOTALL).group()
    
    body = '\n'.join(paragraphs_xml)
    new_doc = f'{ns_part}<w:body>{body}\n{sectPr}</w:body></w:document>'
    open(os.path.join(work_dir, 'word/document.xml'), 'w', encoding='utf-8').write(new_doc)
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
        for root, dirs, files in os.walk(work_dir):
            for file in files:
                fp = os.path.join(root, file)
                zout.write(fp, os.path.relpath(fp, work_dir))

def heb_para(text, bold=False, size=24, color=None, space_before=None, space_after=None):
    spacing = ''
    if space_before or space_after:
        sp = '<w:spacing'
        if space_before: sp += f' w:before="{space_before}"'
        if space_after: sp += f' w:after="{space_after}"'
        spacing = sp + '/>'
    rPr = '<w:rFonts w:hint="cs"/>'
    if bold: rPr += '<w:b/><w:bCs/>'
    if size: rPr += f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>'
    if color: rPr += f'<w:color w:val="{color}"/>'
    rPr += '<w:rtl/>'
    t_attr = ' xml:space="preserve"' if ' ' in text else ''
    return (f'<w:p><w:pPr><w:bidi/>{spacing}<w:rPr><w:rtl/></w:rPr></w:pPr>'
            f'<w:r><w:rPr>{rPr}</w:rPr><w:t{t_attr}>{text}</w:t></w:r></w:p>')

def heb_bullet(text, size=24, space_after=80):
    rPr = f'<w:rFonts w:hint="cs"/><w:sz w:val="{size}"/><w:szCs w:val="{size}"/><w:rtl/>'
    t_attr = ' xml:space="preserve"' if ' ' in text else ''
    return (f'<w:p><w:pPr>'
            f'<w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>'
            f'<w:bidi/><w:spacing w:after="{space_after}"/>'
            f'<w:rPr><w:rtl/></w:rPr></w:pPr>'
            f'<w:r><w:rPr>{rPr}</w:rPr><w:t{t_attr}>{text}</w:t></w:r></w:p>')

def heb_empty():
    return '<w:p><w:pPr><w:bidi/><w:rPr><w:rtl/></w:rPr></w:pPr></w:p>'
